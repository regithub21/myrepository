﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestaurantOrderApp.Model
{
    public class Dish
    {
        public string Id { get; set; }
        public string DishName { get; set; }
        public int Quantity { get; set; }
        public EPeriod Period { get; set; }
        public bool FlgAllowMultiple { get; set; }
    }

    public enum EPeriod
    {
        Morning,
        Night
    }
}

