﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestaurantOrderApp
{
    interface IRestaurantOrder
    {
        String ReturnOrder(string a, string b);
    }
}

