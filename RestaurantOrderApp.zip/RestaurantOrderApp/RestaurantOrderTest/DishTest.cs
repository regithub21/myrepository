﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using RestaurantOrderApp;

namespace RestaurantOrderTest
{
    [TestClass]
    public class DishTest
    {
        [TestMethod]
        public void ReturnOrderTest()
        {
            string periodvalue = "Morning";
            string insertedvalue = "3,2,1";
            string expectedvalue = "eggs, toast, coffee";
            RestaurantOrder restaurantOrder = new RestaurantOrder("Morning", "3,2,1");

            restaurantOrder.ReturnOrder(periodvalue, insertedvalue);

            //// assert
            string returnedvalue = restaurantOrder._Orderreturn;
            Assert.IsTrue(expectedvalue == returnedvalue, "SUCCESS");
        }
    }
}
