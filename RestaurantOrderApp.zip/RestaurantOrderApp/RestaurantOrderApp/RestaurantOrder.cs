﻿using RestaurantOrderApp.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestaurantOrderApp
{
    public class RestaurantOrder : IRestaurantOrder
    {
        private string _periodinserted;
        private string _orderreturn;

        public string _Orderreturn
        {
            get { return _orderreturn; }
        }

        private RestaurantOrder()
        {

        }

        public RestaurantOrder(string periodinserted, string orderreturn)
        {
            _orderreturn = orderreturn;
            _periodinserted = periodinserted;
        }

        public string ReturnOrder(string period, string order)
        {
            string[] orderLst = order.Split(new[] { "," }, StringSplitOptions.None);
            List<Dish> lstDishReturn = new List<Dish>();
            Dish objDish = new Dish();

            try
            {
                List<Dish> lstDish = ReturnDish();

                foreach (var itemDish in orderLst)
                {
                    try
                    {
                        var dish = lstDish.Where(x => x.Id == itemDish && period.ToUpper() == x.Period.ToString().ToUpper()).Single();
                        lstDishReturn.Add(dish);
                    }
                    catch
                    {
                        string result = string.Join(", ", lstDish.Where(x => period == x.Period.ToString().ToUpper()).Select(x => x.Id + "-" + x.DishName).ToArray());
                        return "Invalid choice, list of possible choices: " + result;
                    }
                }

                var group = lstDishReturn.GroupBy(x => x.DishName)
                    .Select(
                    g => new
                    {
                        Id = g.First().Id,
                        DishName = g.First().DishName,
                        Sum = g.Sum(x => x.Quantity),
                        AllowMultiple = g.First().FlgAllowMultiple
                    });

                lstDishReturn = new List<Dish>();
                foreach (var item in group)
                {
                    objDish = new Dish();

                    if (item.AllowMultiple != true && item.Sum > 1)
                    {
                        _orderreturn = "You can't choose more then one dish instead of eggs in the Morning and Potatos in the night.";

                        return _orderreturn;
                    }

                    if (item.AllowMultiple == true && item.Sum > 1)
                    {
                        objDish.DishName = item.DishName + "(x" + item.Sum.ToString() + ")";
                    }
                    else
                    {
                        objDish.DishName = item.DishName;
                    }

                    objDish.Id = item.Id;
                    objDish.Quantity = item.Sum;

                    lstDishReturn.Add(objDish);
                }

                _orderreturn = string.Join(", ", lstDishReturn.OrderBy(x => x.Id).Select(x => x.DishName).ToArray());
            }
            catch
            {
                throw new ArgumentException();
            }

            return _orderreturn;
        }

        private static List<Dish> ReturnDish()
        {
            List<Dish> lstDish = new List<Dish>();
            lstDish.Add(new Dish() { Id = "1", DishName = "eggs", Quantity = 1, Period = EPeriod.Morning, FlgAllowMultiple = true });
            lstDish.Add(new Dish() { Id = "2", DishName = "toast", Quantity = 1, Period = EPeriod.Morning, FlgAllowMultiple = false });
            lstDish.Add(new Dish() { Id = "3", DishName = "coffee", Quantity = 1, Period = EPeriod.Morning, FlgAllowMultiple = false });
            lstDish.Add(new Dish() { Id = "1", DishName = "steak", Quantity = 1, Period = EPeriod.Night, FlgAllowMultiple = false });
            lstDish.Add(new Dish() { Id = "2", DishName = "potato", Quantity = 1, Period = EPeriod.Night, FlgAllowMultiple = true });
            lstDish.Add(new Dish() { Id = "3", DishName = "wine", Quantity = 1, Period = EPeriod.Night, FlgAllowMultiple = false });
            lstDish.Add(new Dish() { Id = "4", DishName = "cake", Quantity = 1, Period = EPeriod.Night, FlgAllowMultiple = false });

            return lstDish;
        }

        static void Main(string[] args)
        {
            Console.WriteLine("Type the period, and then press Enter");
            string period = Console.ReadLine();
            if (period.ToUpper() != "MORNING" && period.ToUpper() != "NIGHT")
            {
                Console.WriteLine("The options are Morning ou Night");
                Console.ReadKey();
                return;
            }

            Console.WriteLine("Type the with order comma separator (1,2,3), and then press Enter");
            string order = Console.ReadLine();
            RestaurantOrder restaurant = new RestaurantOrder();

            Console.WriteLine("Output: " + restaurant.ReturnOrder(period.ToUpper(), order));
            Console.ReadKey();

        }

    }
}

